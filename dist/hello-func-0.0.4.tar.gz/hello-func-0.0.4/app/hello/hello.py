def hello_def(usr: str):
    print(f'Hello, {usr}')
